import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import Login from './components/Login';
import Register from './components/Register';
import TaskManager from './components/TaskManager';
import TaskDetails from './components/TaskDetails'; // Ensure this path is correct or update it to the correct path
import TaskForm from './components/TaskForm'; // Ensure this path is correct or update it to the correct path
// If the file does not exist, create it or update the path accordingly
import './App.css';
const App: React.FC = () => {
    return (
        <Router>
            <Switch>
                <Route path="/register" component={Register} />
                <Route path="/login" component={Login} />
                <Route path="/tasks/new" component={TaskForm} />
                <Route path="/tasks/:id" component={TaskDetails} />
                <Route path="/tasks" component={TaskManager} />
                <Route path="/" component={TaskManager} />
            </Switch>
        </Router>
    );
};

export default App;