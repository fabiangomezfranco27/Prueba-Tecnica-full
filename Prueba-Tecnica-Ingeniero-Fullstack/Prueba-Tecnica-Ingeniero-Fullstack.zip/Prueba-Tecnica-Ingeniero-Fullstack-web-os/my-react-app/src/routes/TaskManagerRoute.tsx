import React from 'react';
import { Route } from 'react-router-dom';
import TaskManager from '../components/TaskManager';

const TaskManagerRoute: React.FC = () => {
    return (
        <Route path="/task-manager" component={TaskManager} />
    );
};

export default TaskManagerRoute;