import axios from 'axios';

const api = axios.create({
  baseURL: 'https://api.example.com', // Cambia esto por la URL de tu API
  headers: {
    'Content-Type': 'application/json',
  },
});

interface UserCredentials {
  username: string;
  password: string;
}

interface UserData {
  username: string;
  password: string;
  email: string;
}

interface TaskData {
  title: string;
  description: string;
}

interface ApiResponse<T> {
  data: T;
}

export const registerUser = async (userData: UserData): Promise<ApiResponse<any>> => {
  const response = await api.post<ApiResponse<any>>('/register', userData);
  return response.data;
};

interface LoginCredentials {
  username: string;
  password: string;
}

interface LoginResponse {
  token: string;
  user: {
    id: string;
    username: string;
    email: string;
  };
}

export const loginUser = async (credentials: LoginCredentials): Promise<ApiResponse<LoginResponse>> => {
  const response = await api.post<ApiResponse<LoginResponse>>('/login', credentials);
  return response.data;
};

export const fetchTasks = async () => {
  const response = await api.get('/tasks');
  return response.data;
};

interface CreateTaskResponse {
  id: string;
  title: string;
  description: string;
}

export const createTask = async (taskData: TaskData): Promise<ApiResponse<CreateTaskResponse>> => {
  const response = await api.post<ApiResponse<CreateTaskResponse>>('/tasks', taskData);
  return response.data;
};

interface DeleteTaskResponse {
  message: string;
}

export const deleteTask = async (taskId: string): Promise<ApiResponse<DeleteTaskResponse>> => {
  const response = await api.delete<ApiResponse<DeleteTaskResponse>>(`/tasks/${taskId}`);
  return response.data;
};