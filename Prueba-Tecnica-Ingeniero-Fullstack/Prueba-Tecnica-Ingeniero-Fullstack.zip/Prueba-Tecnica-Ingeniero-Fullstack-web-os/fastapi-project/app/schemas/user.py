from pydantic import BaseModel, EmailStr
from typing import Optional

class UserBase(BaseModel):
    email: str

class UserCreate(UserBase):
    password: str

class UserUpdate(BaseModel):
    email: Optional[str] = None
    password: Optional[str] = None

class UserResponse(UserBase):
    id: int
    model_config = {
        "from_attributes": True
    }

__all__ = ["UserBase", "UserCreate", "UserUpdate", "UserResponse"]