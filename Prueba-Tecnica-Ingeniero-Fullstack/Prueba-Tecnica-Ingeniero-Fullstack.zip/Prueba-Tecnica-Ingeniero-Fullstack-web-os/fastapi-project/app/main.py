from fastapi import FastAPI
from app.database import engine
from app.models import user, task
from app.routers import user as user_router, task as task_router

# Crear la instancia de FastAPI
app = FastAPI()

# Incluir routers
app.include_router(user_router.router, prefix="/users", tags=["users"])
app.include_router(task_router.router, prefix="/tasks", tags=["tasks"])

# Crear las tablas en la base de datos
@app.on_event("startup")
async def startup():
    async with engine.begin() as conn:
        await conn.run_sync(user.Base.metadata.create_all)
        await conn.run_sync(task.Base.metadata.create_all)