from app.database import Base, engine
from app.models import User, Task  # Importa los modelos aquí

# Crear todas las tablas
Base.metadata.create_all(bind=engine)