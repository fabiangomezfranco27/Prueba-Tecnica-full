import logging
from app.database import Base, engine, SessionLocal
from app.models.user import User
from app.models.task import Task

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def init_db():
    try:
        Base.metadata.create_all(bind=engine)
        logger.info("✅ Tablas creadas")
        
        db = SessionLocal()
        try:
            # Crear usuario de prueba
            user = User(
                email="test@example.com",
                name="Test User",
                hashed_password="test123"
            )
            db.add(user)
            db.commit()
            logger.info("✅ Usuario creado")
            
            # Crear tarea de prueba
            task = Task(
                title="Test Task",
                description="Test Description",
                user_id=user.id
            )
            db.add(task)
            db.commit()
            logger.info("✅ Tarea creada")
        finally:
            db.close()
    except Exception as e:
        logger.error(f"❌ Error: {str(e)}")
        raise

if __name__ == "__main__":
    init_db()